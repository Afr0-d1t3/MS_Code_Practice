print('Counting to 100 by fives:')
i = 5
while i <= 100:
    print(i)
    i += 5
print('List complete!')