spices = [
    'salt',
    'pepper',
    'cumin',
    'turmeric',
]
for spice in spices:
    print(spice)
print('No more boring omelettes!')
