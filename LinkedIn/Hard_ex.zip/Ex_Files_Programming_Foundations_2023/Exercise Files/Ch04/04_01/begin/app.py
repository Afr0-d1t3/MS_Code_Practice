value = input('Enter a number: ')
print(value)
