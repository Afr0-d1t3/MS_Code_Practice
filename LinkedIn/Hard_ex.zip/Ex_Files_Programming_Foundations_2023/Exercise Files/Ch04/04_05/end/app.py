miles = input('Enter a distance in miles: ')
miles_float = float(miles)
# kilometers_value = miles_value * 1.609344
kilometers = miles_float * 1.609344
print('That value in kilometers is')
print(kilometers)