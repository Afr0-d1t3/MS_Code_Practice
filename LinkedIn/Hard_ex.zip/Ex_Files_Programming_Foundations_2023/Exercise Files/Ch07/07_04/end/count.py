i = 10
while i > 0:
    i -= 1
    print(i) 
