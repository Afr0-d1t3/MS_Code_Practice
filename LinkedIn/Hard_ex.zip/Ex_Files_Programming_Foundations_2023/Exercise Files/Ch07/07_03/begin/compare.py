temperature = 50

if temp < 60
    print(Bring a jacket)
