# Office locations
# city1 = 'Tokyo'
# city2 = 'Dakar'
# city3 = 'Mumbai'
# city4 = 'Buenos Aires'

cities = [
    'Tokyo', 
    'Dakar', 
    'Mumbai', 
    'Buenos Aires',
]

print(cities[1])