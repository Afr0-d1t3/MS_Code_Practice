# California state symbols
state_bird = 'California quail'
state_animal = 'Grizzly bear'
state_flower = 'California poppy'
state_fruit = 'Avocado'
