import testmodule

testmodule.mult(10, 5)